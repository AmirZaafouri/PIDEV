/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.challange.gui;
import Mail.javamail.JavaMailUtil;
import edu.worshop.entites.Challenges;
import edu.worshop.entites.Formation;
import edu.worshop.entites.HighChallengePublier;
import edu.worshop.entites.Studio;
import edu.worshop.services.ChallengeCrud;
import edu.worshop.services.FormationCrud;
import edu.worshop.services.InterfaceChallenges;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;



/**
 * FXML Controller class
 *
 * @author msi
 */
public class LaboController implements Initializable {
    int myIndex;
    int txtidStudio;
    int txtidChallenge;
    @FXML
    private Label MenuClose;
    @FXML
    private Button btAllChallenge;
    @FXML
    private Button btchallenge;
    private GridPane PnAdd;
    @FXML
    private GridPane PnChallenge;
    @FXML
    private TextField TXTdure;
    @FXML
    private TextField TXTdescrip;
    @FXML
    private TextField TXTrecmpense;
    @FXML
    private TableView<Challenges> TableChallenges;
    @FXML
    private TableColumn<Challenges, String> Columnduree;
    @FXML
    private TableColumn<Challenges, String> Columnrecompense;
    @FXML
    private TableColumn<Challenges, String> Columndescription;
    @FXML
    private TableColumn<Challenges, Integer> ColumnIdChallenge;
    @FXML
    private TableColumn<Challenges, Integer> ColumnIdStudio;
 
    @FXML
    private Button Ajouterchallenge;
    @FXML
    private Button delletedchallenge;
    @FXML
    private Button Updaterchallenge;
    private Button btBackup;
    private GridPane PnBackup;
    @FXML
    private GridPane PnAllChallenge;
    private TableView<Challenges> TableAllChallenge;
    private TableColumn<Challenges, String> columnDureeC;
    private TableColumn<Challenges, String> columnRecomponseC;
    private TableColumn<Challenges, String> ColumnDescriptionC;
    @FXML
    private Label error_recompense;
    @FXML
    private Label error_description;
    @FXML
    private Label error_duree;
    @FXML
    private TableView<Challenges> tabelNbrChallenge;
    @FXML
    private TableColumn<Challenges, String> ColumnIdStudioT3;
    @FXML
    private TableColumn<Challenges, Integer> ColumnIdNbrCT3;
    @FXML
    private Button btHightRecomponse;
    @FXML
    private TableView<HighChallengePublier> tabelHightRecompense;
    @FXML
    private TableColumn<HighChallengePublier, String> ColumnNameManger;
    @FXML
    private TableColumn<HighChallengePublier, Integer> ColumnRecompense3;
    @FXML
    private Button btMood;
    @FXML
    private ImageView ImgMood;
    @FXML
    private GridPane grid;
     @FXML
    private TextField TXTimg;
    @FXML
    private Button btImportImg;
    @FXML
    private GridPane PnStatChallenge;
    @FXML
    private Button btStatChallenge;
    @FXML
    private TextField chercherMagasin;
    @FXML
    private ImageView lbl_image;
     @FXML
    private Label error_img;
    //----------------DALI------------------
    @FXML
    private ComboBox<?> comboCat;
    @FXML
    private ScrollPane scroll;
  
    @FXML
    private Button btAjouterFormation;
    @FXML
    private Button btconsulterFormations;
    @FXML
    private GridPane pnAjouterFormation;
    @FXML
    private TextField fnom;
    @FXML
    private TextField fduree;
    @FXML
    private TextField fdisc;
    @FXML
    private Spinner<Integer> fprix;
    @FXML
    private Button AjouterF;
    @FXML
    private Label msg;
    @FXML
    private GridPane pnAfficheFormations;
    @FXML
    private AnchorPane sceneAffichage;
    @FXML
    private TableView<Formation> tableF;
    @FXML
    private TableColumn<Formation, Integer> tid;
    @FXML
    private TableColumn<Formation, String> tnom;
    @FXML
    private TableColumn<Formation, String> tduree;
    @FXML
    private TableColumn<Formation, Integer> tprix;
    @FXML
    private TableColumn<Formation, Integer> tIdstudio;
    @FXML
    private TableColumn<Formation, String> tdiscp;
    @FXML
    private TextField mnom;
    @FXML
    private TextField mduree;
    @FXML
    private TextField mdisc;
    @FXML
    private Spinner<Integer> mprix;
    @FXML
    private Button ModifierF;
    @FXML
    private Button SupprimerF;
    @FXML
    private Label labelm;
    
    @FXML
    private TableView<Formation> tabelNbrFormations;
    @FXML                                                   //bch ttzed m3a Métier Challenge
    private TableColumn<Formation, Integer> ColumnIdNbrFR3;
     @FXML
    private TableColumn<Formation,String> ColumnIdStudioFR;                    
    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^DALI^^^^^^^^^^^^^^^^^^^^^^
    
    
   
 
   
    
  

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
           InterfaceChallenges sp = new ChallengeCrud();
        List<Challenges> eqs = sp.afficheChallanges();
        try {
            afficherEquipementsMag(eqs);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        // TODO
//        table();   
//        table2();   
    //    table3();  
        

    }    

    @FXML
    private void handleClick(ActionEvent event) {
             if (event.getSource() == btchallenge){
        
        PnChallenge.toFront();
        tableMonChallenge(); 
        }
        
          if (event.getSource() == btAllChallenge){
        
       PnAllChallenge.toFront();
      
   InterfaceChallenges sp = new ChallengeCrud();
        List<Challenges> eqs = sp.afficheChallanges();
        try {
            afficherEquipementsMag(eqs);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        }
           if (event.getSource() == btStatChallenge){
        
        PnStatChallenge.toFront();
        table3Stat();
        
        }
           
           
           if(event.getSource() == btconsulterFormations){
           pnAfficheFormations.toFront();
            tableFormation();
           }
            if(event.getSource() == btAjouterFormation){
           pnAjouterFormation.toFront();
           
           }
           
    }

    @FXML
    private void updateChallenge(ActionEvent event) {
         Alert alert = new Alert(Alert.AlertType.INFORMATION);
    
           ChallengeCrud Cc= new ChallengeCrud();
        String descrption,duree,recomponce,ImgUrl;
        myIndex = TableChallenges.getSelectionModel().getSelectedIndex();
        txtidChallenge = Integer.parseInt(String.valueOf(TableChallenges.getItems().get(myIndex).getIdchallange()));
        txtidStudio=Integer.parseInt(String.valueOf(TableChallenges.getItems().get(myIndex).getStudio_id())); 
               boolean isdureeEmpty = Validation.TextFieldValidations.isTextFieldNoEmpty(TXTdure, error_duree, "Durre est vide");
                boolean isRecompenseEmpty = Validation.TextFieldValidations.isTextFieldNoEmpty(TXTrecmpense, error_recompense, "Recompense est vide");
                  boolean isDescritionEmpty = Validation.TextFieldValidations.isTextFieldNoEmpty(TXTdescrip, error_description, "Description est vide");
                    boolean isImgUrlEmpty = Validation.TextFieldValidations.isTextFieldNoEmpty(TXTimg, error_img, "NO image Found !!");
                  
      
                  
                  
        if(!(isDescritionEmpty && isdureeEmpty && isRecompenseEmpty && isImgUrlEmpty)){
         alert.setTitle("WARNING !!");
            alert.setHeaderText("Can't be Updated Like that ");
            alert.setContentText("invalid field ");
    alert.showAndWait();
    }
    else{ 
            recomponce = TXTrecmpense.getText();
            duree = TXTdure.getText();
            descrption = TXTdescrip.getText();
            ImgUrl=TXTimg.getText();
            ImgUrl=ImgUrl.replace("\\", "\\\\");
            System.out.println("txtidChallenge : "+txtidChallenge+"\n");
          
                Challenges g=new Challenges( txtidChallenge,duree, recomponce, txtidStudio,descrption,ImgUrl);
                Cc.modifierChallenges(g);
      
        alert.setTitle("Challenge Registationn");
 
        alert.setHeaderText("U Want the change ");
        alert.setContentText("Updateddd!");
 
        alert.showAndWait();
                tableMonChallenge();
        }
    }

    @FXML
    private void supprimerChallenge(ActionEvent event) {
        ChallengeCrud Cc= new ChallengeCrud();
       
        myIndex = TableChallenges.getSelectionModel().getSelectedIndex();
        txtidChallenge = Integer.parseInt(String.valueOf(TableChallenges.getItems().get(myIndex).getIdchallange()));
      
        
       
          
                Cc.suprimerChallenges(txtidChallenge);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Challenge Registationn");
 
            alert.setHeaderText("U Want Deleted Challenge ");
            alert.setContentText("SUPPRIMER!");
 
            alert.showAndWait();
                tableMonChallenge();
    }

    @FXML
    private void addChallenge(ActionEvent event) {
         Alert alert = new Alert(Alert.AlertType.INFORMATION);
        boolean isdureeEmpty = Validation.TextFieldValidations.isTextFieldNoEmpty(TXTdure, error_duree, "Durre est vide !!");
        boolean isRecompenseEmpty = Validation.TextFieldValidations.isTextFieldNoEmpty(TXTrecmpense, error_recompense, "Recompense est vide !!");
         boolean isDescritionEmpty = Validation.TextFieldValidations.isTextFieldNoEmpty(TXTdescrip, error_description, "Description est vide !!");
          boolean isImgUrlEmpty = Validation.TextFieldValidations.isTextFieldNoEmpty(TXTimg, error_img, "NO image Found !!");
        System.out.printf("Validation :"+isdureeEmpty + isDescritionEmpty +isDescritionEmpty);
    if(!(isDescritionEmpty && isdureeEmpty && isRecompenseEmpty && isImgUrlEmpty)){
         alert.setTitle("WARNING !!");
            alert.setHeaderText("Can't be ADD Like that ");
            alert.setContentText("invalid field ");
    alert.showAndWait();
    }
    else{  
         ChallengeCrud Cc= new ChallengeCrud();
        String descrption,duree,recomponce,imgUrl;
       
        txtidStudio =1;
            recomponce = TXTrecmpense.getText();
            duree = TXTdure.getText();
            descrption = TXTdescrip.getText();
           
            imgUrl=TXTimg.getText();
            imgUrl=imgUrl.replace("\\", "\\\\");
        
       
                Challenges g=new Challenges( duree, recomponce, descrption,imgUrl);
                    // System.out.println("txtidChallenge : "+g+"\n");
               
           
alert.setTitle("Challenge Registationn");
 
alert.setHeaderText("U Want to ADD New CHALLENGE ");
alert.setContentText("ADD!");
  Cc.ajouterChallenges(g, txtidStudio);
alert.showAndWait();
                tableMonChallenge();}
        
    }
    
    //Affiche seulement mon Challenge  publier +interface ajouter+modif+supp
      public void tableMonChallenge(){
      ChallengeCrud Cc= new ChallengeCrud();
     ArrayList<Challenges> challengess = new ArrayList<>();
              
                     challengess= (ArrayList<Challenges>) Cc.afficheMonChallanges(1);
              
  
    ObservableList<Challenges> obsl = FXCollections.observableArrayList(challengess); 
  
    TableChallenges.setItems(obsl);
    
    ColumnIdChallenge.setCellValueFactory(new  PropertyValueFactory<>("idchallange"));    
      Columnduree.setCellValueFactory(new  PropertyValueFactory<>("duree"));
    Columnrecompense.setCellValueFactory(new  PropertyValueFactory<>("recompense"));
   Columndescription.setCellValueFactory(new  PropertyValueFactory<>("description"));
   ColumnIdStudio.setCellValueFactory(new  PropertyValueFactory<>("studio_id"));

 TableChallenges.setRowFactory( tv -> {
     TableRow<Challenges> myRow = new TableRow<>();
     myRow.setOnMouseClicked (event ->
     {
        if (event.getClickCount() == 1 && (!myRow.isEmpty()))
        {
            myIndex =  TableChallenges.getSelectionModel().getSelectedIndex();
        
             txtidChallenge=Integer.parseInt(String.valueOf(TableChallenges.getItems().get(myIndex).getIdchallange()));               
             txtidStudio=Integer.parseInt(String.valueOf(TableChallenges.getItems().get(myIndex).getStudio_id()));               
             TXTdure.setText(TableChallenges.getItems().get(myIndex).getDuree());            
             TXTdescrip.setText(TableChallenges.getItems().get(myIndex).getDescription()); 
             TXTrecmpense.setText(TableChallenges.getItems().get(myIndex).getRecompense());
             TXTimg.setText(TableChallenges.getItems().get(myIndex).getImg());
            
        String path= TXTimg.getText();
        System.out.println("PATH :"  +path);
       // Image getAbsolutePath = null;
       // ImageIcon icon = new ImageIcon(filename);

    
    
             Image imn = new Image(
              "file:/" +path );
        lbl_image.setImage(imn);         
             
        }
     });
        return myRow;
                   });
    
    }
      
      
            public void table2(){
      ChallengeCrud Cc= new ChallengeCrud();
     ArrayList<Challenges> challengess = new ArrayList<>();
              
                     challengess= (ArrayList<Challenges>) Cc.afficheChallanges();
              
  
    ObservableList<Challenges> obsl = FXCollections.observableArrayList(challengess); 
  
    TableAllChallenge.setItems(obsl);
    
    
      columnDureeC.setCellValueFactory(new  PropertyValueFactory<>("duree"));
    columnRecomponseC.setCellValueFactory(new  PropertyValueFactory<>("recompense"));
   ColumnDescriptionC.setCellValueFactory(new  PropertyValueFactory<>("description"));

    
    }
          //Affichage fi PG Statis Nbr du challenge publier par chaque studio  
               public void table3Stat(){
      ChallengeCrud Cc= new ChallengeCrud();
      FormationCrud Fc= new FormationCrud();
      ArrayList<Formation> formationss = new ArrayList<>();
                       formationss= (ArrayList<Formation>) Fc.afficheStudioNBFormations();
     ArrayList<Challenges> challengess = new ArrayList<>();
              
                     challengess= (ArrayList<Challenges>) Cc.afficheStudioNBChallanges();
              
  
    ObservableList<Challenges> obsl = FXCollections.observableArrayList(challengess); 
   ObservableList<Formation> obs2 = FXCollections.observableArrayList(formationss); 
    tabelNbrChallenge.setItems(obsl);
    tabelNbrFormations.setItems(obs2);
    
      ColumnIdStudioT3.setCellValueFactory(new  PropertyValueFactory<>("nom_qui_a_publier"));
    ColumnIdNbrCT3.setCellValueFactory(new  PropertyValueFactory<>("NbrChallangePublier"));
    ColumnIdStudioFR.setCellValueFactory(new  PropertyValueFactory<>("nom_persone_publier"));
      ColumnIdNbrFR3.setCellValueFactory(new  PropertyValueFactory<>("nbrFormationpublier"));
     System.out.println();
     
     

    
    }

               public void table4(){
      ChallengeCrud Cc= new ChallengeCrud();
     ArrayList<HighChallengePublier> hightchallengess = new ArrayList<>();
              
                     hightchallengess= (ArrayList<HighChallengePublier>) Cc.HightRecompenseChallanges();
              
  
    ObservableList<HighChallengePublier> obsl = FXCollections.observableArrayList(hightchallengess); 
  
    tabelHightRecompense.setItems(obsl);
    
    
      ColumnNameManger.setCellValueFactory(new  PropertyValueFactory<>("nomManger"));
    ColumnRecompense3.setCellValueFactory(new  PropertyValueFactory<>("PrixChallenge"));

    }
    @FXML
    private void ShowHightPrixC(ActionEvent event) {
        table4();
    }

    private boolean isLightMood=true; 
    @FXML
    private void ChangeMood(ActionEvent event) {
        isLightMood=!isLightMood;
        if (isLightMood){
        setLightMode();
        }
        else{
            setDarkMode();
        }
    }

    private void setLightMode() {
   PnAllChallenge.getStylesheets().remove("styles/DarkMode.css");
   PnAllChallenge.getStylesheets().add("styles/LghtkMode.css");
   Image image =new Image ("edu.challange.gui.Images/moon.png");
   ImgMood.setImage(image);
    }

    private void setDarkMode() {
       PnAllChallenge.getStylesheets().remove("styles/LghtkMode.css");
   PnAllChallenge.getStylesheets().add("styles/DarkMode.css");
   Image image =new Image ("edu.challange.gui.Images/menu1.png");
   ImgMood.setImage(image);
    }
         
    public void afficherEquipementsMag(List<Challenges> eqs) throws IOException {
            InterfaceChallenges sc = new ChallengeCrud();
        int column = 0;
        int row = 1;
        List<Challenges> listProd = sc.afficheChallanges();
        try{
        for (int i = 0; i < listProd.size(); i++) {

            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("itemEquipement.fxml"));
            AnchorPane anchorPane = fxmlLoader.load();

            ItemController itemController = fxmlLoader.getController();
            
            itemController.setData(listProd.get(i));

            if (column == 1) {
                column = 0;
                row++;
            }

            grid.add(anchorPane, column++, row); //(child,column,row)
            //set grid width
            grid.setMinWidth(Region.USE_COMPUTED_SIZE);
            grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
            grid.setMaxWidth(Region.USE_PREF_SIZE);

            //set grid height
            grid.setMinHeight(Region.USE_COMPUTED_SIZE);
            grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
            grid.setMaxHeight(Region.USE_PREF_SIZE);

            GridPane.setMargin(anchorPane, new Insets(10));
        }
            }catch(IOException ex){
                     ex.printStackTrace();
                    }
    }  
    
     @FXML
    private void Import_Img(ActionEvent event) {
        
        JFileChooser  chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        String filename = f.getAbsolutePath();
        TXTimg.setText(filename);
        String path= TXTimg.getText();
        System.out.println("PATH :"  +path);
       // Image getAbsolutePath = null;
       // ImageIcon icon = new ImageIcon(filename);

    
    
             Image imn = new Image(
              "file:/" +path );
        lbl_image.setImage(imn);
//       // System.out.println("file:/" + eq.getImage_eq());
                }
    @FXML
    private void chercherProduitsMag(KeyEvent event) {
    }

    @FXML
    private void clearSelection(MouseEvent event) {
    }

    @FXML
    private void trierCat(ActionEvent event) {
    }

    @FXML
    private void switchToItemInt(MouseEvent event) {
    }
//---------------------- DALI --------------------------
     int txtidForamtion;
    
    public void validationF() throws Exception {

        if (fnom.getText().trim().isEmpty()) {
            Alert fail = new Alert(Alert.AlertType.INFORMATION);
            fail.setTitle("Information Dialog");
            fail.setHeaderText("Erreur");
            fail.setContentText("Vous devez ajouter un nom!");
            fail.showAndWait();
            throw new Exception("Exception message");

        }
        if (fduree.getText().trim().isEmpty()) {
            Alert fail = new Alert(Alert.AlertType.INFORMATION);
            fail.setTitle("Information Dialog");
            fail.setHeaderText("Erreur");
            fail.setContentText("Vous devez ajouter une durée!");
            fail.showAndWait();
            throw new Exception("Exception message");

        }
        if (fdisc.getText().trim().isEmpty()) {
            Alert fail = new Alert(Alert.AlertType.INFORMATION);
            fail.setTitle("Information Dialog");
            fail.setHeaderText("Erreur");
            fail.setContentText("Vous devez ajouter une description!");
            fail.showAndWait();
            throw new Exception("Exception message");

        }
    }
    
    
    @FXML
    private void AjouterF(ActionEvent event)throws Exception {

        String nom, description, duree;
        final int prix;
        nom = fnom.getText();
        description = fdisc.getText();
        duree = fduree.getText();

        //SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(100,1000 ,100, 5);
        //fprix.setValueFactory(valueFactory);
        fprix.setEditable(true);
        prix = fprix.getValue();

        //String s=String.valueOf(prix);
        Formation e = new Formation(nom, duree, description, prix);
        FormationCrud Cc = new FormationCrud();
        Studio S = new Studio(1, "UBISOFT manager", "joseph kerssbi", "joseph123@gmail.com", "55619255", "Studio Manager");

        try {
            validationF();
            Cc.ajouterFormation(e, S);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        //msg.setVisible(true);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setTitle("Information Dialog");

        alert.setHeaderText(null);

        alert.setContentText("Formation ajoutée avec succés!");
        alert.showAndWait();

           
   
    }


    @FXML
    private void ModifierF(ActionEvent event)throws SQLException, Exception {

        String descrption, duree, nom;
        final int prix,p;
        nom = mnom.getText();
        duree = mduree.getText();
        descrption = mdisc.getText();
        mprix.setEditable(true);
        prix = mprix.getValue();
        p=mprix.getValue();
        FormationCrud Cc = new FormationCrud();
        Formation g = new Formation(txtidForamtion, nom, duree, descrption, prix, txtidStudio);
        Cc.modifierFormation(g);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(" Modification");
        alert.setHeaderText("Vous voulez Modifier cette formation? ");
        alert.showAndWait();
        tableFormation();
     
        labelm.setVisible(true);
            if (prix<200) {
            Alert mail = new Alert(Alert.AlertType.CONFIRMATION);
            mail.setTitle(" Mailing");
            mail.setHeaderText("Vous voulez Notifier les utilisateurs de cette reduction? ");
            mail.showAndWait();

            JavaMailUtil.sendMail("zaafouri.amir@esprit.tn");
            Alert succes = new Alert(Alert.AlertType.INFORMATION);
            succes.setTitle("Information Dialog");
            succes.setHeaderText(null);
            succes.setContentText("Email Envoyée avec succés!");
            succes.showAndWait();
        }
tableFormation();
 labelm.setVisible(false);
    }

    @FXML
    private void SupprimerF(ActionEvent event) {
         FormationCrud Cc = new FormationCrud();
        //Studio S=new Studio(1, "UBISOFT manager", "joseph kerssbi", "joseph123@gmail.com", "55619255", "Studio Manager");

        myIndex = tableF.getSelectionModel().getSelectedIndex();
        txtidForamtion = Integer.parseInt(String.valueOf(tableF.getItems().get(myIndex).getIdformation()));

        Cc.suprimerFormation(txtidForamtion);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(" Suppression");

        alert.setHeaderText("Vous voulez supprimer cette formation? ");

        alert.showAndWait();
    tableFormation();
        
    }
    
        public void tableFormation() {

        // TODO
        FormationCrud Cc = new FormationCrud();
        ArrayList<Formation> list = new ArrayList<>();

        list = (ArrayList<Formation>) Cc.afficheFormation();

        ObservableList<Formation> obsl = FXCollections.observableArrayList(list);

        tableF.setItems(obsl);

        tid.setCellValueFactory(new PropertyValueFactory<>("idformation"));
        tduree.setCellValueFactory(new PropertyValueFactory<>("duree"));
        tnom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        tprix.setCellValueFactory(new PropertyValueFactory<>("prix"));
        tIdstudio.setCellValueFactory(new PropertyValueFactory<>("studio_id"));
        tdiscp.setCellValueFactory(new PropertyValueFactory<>("description"));

        tableF.setRowFactory(tv -> {
            TableRow<Formation> myRow = new TableRow<>();
            myRow.setOnMouseClicked(event
                    -> {
                if (event.getClickCount() == 1 && (!myRow.isEmpty())) {
                    myIndex = tableF.getSelectionModel().getSelectedIndex();

                    txtidForamtion = Integer.parseInt(String.valueOf(tableF.getItems().get(myIndex).getIdformation()));
                    txtidStudio = Integer.parseInt(String.valueOf(tableF.getItems().get(myIndex).getStudio_id()));
                    mduree.setText(tableF.getItems().get(myIndex).getDuree());
                    mdisc.setText(tableF.getItems().get(myIndex).getDescription());
                    mnom.setText(tableF.getItems().get(myIndex).getNom());
                    mprix.getValueFactory().setValue(tableF.getItems().get(myIndex).getPrix());

                }
            });
            return myRow;
        });

    }
//----------------------^^ DALI ^^--------------------------

   
    
}
