package edu.challange.gui;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import edu.worshop.entites.Challenges;
import edu.worshop.entites.HighChallengePublier;
import edu.worshop.entites.ParticperChallenge;
import edu.worshop.services.ChallengeCrud;
import java.io.IOException;
import static java.lang.Integer.parseInt;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author msi
 */
public class ItemController implements Initializable {

    @FXML
    private Label nameLabel;
    @FXML
    private ImageView imgItemProduit;
    @FXML
    private Label priceLable;
    @FXML
    private Label IdItem;
    @FXML
    private Label descriptionlabel;
    @FXML
    private Button btAffParticipant;
    @FXML
    private Button btParticper;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void click(MouseEvent event) {
    }

    public void setData(Challenges eq) throws MalformedURLException {

        this.nameLabel.setText(eq.getRecompense());
        this.priceLable.setText(eq.getDuree());
        this.descriptionlabel.setText(eq.getDescription());
//        this.priceLable.setStrikethrough(true);
        this.IdItem.setText(String.valueOf(eq.getIdchallange()));

//         Image imn = new Image(
//                "/images/" + "Challenge1.png");
//        imgItemProduit.setImage(imn);
//       // System.out.println("file:/" + eq.getImage_eq());
        Image imn = new Image(
                "file:/" + eq.getImg());
        imgItemProduit.setImage(imn);
        System.out.println("file:/" + eq.getImg());
    }

    @FXML
    private void AfficherParticipants(ActionEvent event) {

        tableDuPartcipant();

    }

    @FXML
    private void ParticiperC(ActionEvent event) {
        //ParticiperChallenge(int idchallenge, int idArtist);
    }

    public void tableDuPartcipant() {
        ChallengeCrud Cc = new ChallengeCrud();
        ArrayList<ParticperChallenge> hightchallengess = new ArrayList<>();
        String idChallenge = IdItem.getText();
        int x = parseInt(idChallenge);
        hightchallengess = (ArrayList<ParticperChallenge>) Cc.afficheUserParticiperChallanges(x);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ListParticipant.fxml"));

        try {
            Parent root = loader.load();
            ListParticipantController ac = loader.getController();

            ac.table2(x);
            //tzid attribuit bch t3adik llpage

            IdItem.getScene().setRoot(root);
        } catch (IOException ex) {
            System.out.print(ex.getMessage());
        }

    }

}
