/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.challange.gui;

import edu.worshop.entites.Challenges;
import edu.worshop.entites.ParticperChallenge;
import edu.worshop.services.ChallengeCrud;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author msi
 */
public class ListParticipantController implements Initializable {
   
    @FXML
    private TextField list;
    @FXML
    private TableView<ParticperChallenge> tableDuParticipant;
    @FXML
    private TableColumn<ParticperChallenge, String> columnNmParticpant;
    @FXML
    private TableColumn<ParticperChallenge, String> columnRecompenceL;

    public void setList(TextField list) {
        this.list = list;
    }

    public void setTableDuParticipant(TableView<ParticperChallenge> tableDuParticipant) {
        this.tableDuParticipant = tableDuParticipant;
    }

    public void setColumnNmParticpant(TableColumn<ParticperChallenge, String> columnNmParticpant) {
        this.columnNmParticpant = columnNmParticpant;
    }

    public void setColumnRecompenceL(TableColumn<ParticperChallenge, String> columnRecompenceL) {
        this.columnRecompenceL = columnRecompenceL;
    }

    public TableView<ParticperChallenge> getTableDuParticipant() {
        return tableDuParticipant;
    }

    public TableColumn<ParticperChallenge, String> getColumnNmParticpant() {
        return columnNmParticpant;
    }

    public TableColumn<ParticperChallenge, String> getColumnRecompenceL() {
        return columnRecompenceL;
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
    }    

    public void setList(String list) {
        this.list.setText(list);
    }

    public TextField getList() {
        return list;
    }
    
             public void table2(int idchalleneg){
      ChallengeCrud Cc= new ChallengeCrud();
     ArrayList<ParticperChallenge> challengess = new ArrayList<>();
              
                     challengess= (ArrayList<ParticperChallenge>) Cc.afficheUserParticiperChallanges(idchalleneg);
              
  
    ObservableList<ParticperChallenge> obsl = FXCollections.observableArrayList(challengess); 
  
    tableDuParticipant.setItems(obsl);
    
    
      columnNmParticpant.setCellValueFactory(new  PropertyValueFactory<>("nom_participant"));
    columnRecompenceL.setCellValueFactory(new  PropertyValueFactory<>("RecompenseChallenge"));
  
  
    
    }

  
    
}
