/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.worshop.services;

import edu.worshop.entites.Challenges;
import edu.worshop.entites.HighChallengePublier;
import edu.worshop.entites.ParticperChallenge;
import java.util.List;

/**
 *
 * @author msi
 * @param <Challenges>
 * @param <Studio>
 */
public interface InterfaceChallenges<Challenges,Studio> {
       public void ajouterChallenges (Challenges c,int idstudio);
    public void modifierChallenges (Challenges c);
    public void suprimerChallenges (int idchallenges);
    public List<Challenges> afficheMonChallanges(int idstudio);
    public List<Challenges> afficheChallanges ();
    public List<Challenges> afficheStudioChallanges ();
    public List<Challenges> afficheStudioNBChallanges ();
     public List<HighChallengePublier> HightRecompenseChallanges ();
      public void ParticiperChallenge (int  idchalleneg,int idstudio);
      public List<ParticperChallenge> afficheUserParticiperChallanges(int Idchallenge);
      public Boolean SiARTISTE(int idUser);
      public String getNameUserA(int id);
}
