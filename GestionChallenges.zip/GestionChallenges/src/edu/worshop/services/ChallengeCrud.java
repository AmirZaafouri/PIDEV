/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.worshop.services;

import edu.worshop.entites.Challenges;
import edu.worshop.entites.HighChallengePublier;
import edu.worshop.entites.ParticperChallenge;
import edu.worshop.entites.Studio;
import edu.worshop.utils.MyConnexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author msi
 */
public class ChallengeCrud implements InterfaceChallenges<Challenges,Studio> {
  Connection cnx  ;
    public ChallengeCrud() {
        cnx =MyConnexion.getIstance().getConx() ;
     
    }
    @Override
    public void ajouterChallenges(Challenges c, int idstudio)   {
                String req = "INSERT INTO challanges(`duree`, `recompense`, `description`, `id_studio`,`img`) VALUES ('"+c.getDuree()+"', '"+c.getRecompense()+"', '"+c.getDescription()+"', "+idstudio+", '"+c.getImg()+"')";
        Statement st;
        try {
            st =cnx.createStatement();
            st.executeUpdate(req);
        }catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
    }
 
   @Override
    public void modifierChallenges(Challenges c) {
              String req = "UPDATE challanges SET duree = '" + c.getDuree()+"', recompense = '"+ c.getRecompense()+"', description = '"+ c.getDescription()+"', img = '"+ c.getImg()+"'  WHERE challanges.`id_challange`"+"="+c.getIdchallange();
        Statement st;
        try {
            st =cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("A Challenges was updated successfully!");
        }catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
    }
    @Override
    public void suprimerChallenges(int idchallenges )   {
              String req = "DELETE FROM challanges WHERE `id_challange`="+idchallenges+"" ;
        Statement st;
        try {
            st =cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("A Challenge was deleted successfully!");
        }catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
    } 
   @Override
    public List<Challenges> afficheMonChallanges(int idstudio) {
            List <Challenges> list = new ArrayList<>();
        try {
            String req = "SELECT * FROM challanges where id_studio="+idstudio+"";
            Statement st;
            st =cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while(rs.next()){
                Challenges e = new Challenges (rs.getInt("id_challange"), rs.getString("duree"),rs.getString("recompense"),rs.getInt("id_studio"),rs.getString("description"),rs.getString("img"));
                list.add(e);
            }
            
        }
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
        return list;
       
    }
    @Override
    public List<Challenges> afficheChallanges() {
       List <Challenges> list = new ArrayList<>();
        try {
            String req = "SELECT * FROM challanges";
            Statement st;
            st =cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while(rs.next()){
                Challenges e = new Challenges (rs.getInt("id_challange"), rs.getString("duree"),rs.getString("recompense"),rs.getInt("id_studio"),rs.getString("description"),rs.getString("img"));
                list.add(e);
            }
            
        }
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
        return list;
    }
//Affichage avec jointure GROUPE CHALLANGE PAR ID_STUDIO
    @Override
    public List<Challenges> afficheStudioChallanges() {
          List <Challenges> list = new ArrayList<>();
        try {
            String req = "SELECT * FROM challanges c inner join user u on c.id_studio = u.id_user GROUP  BY c.id_studio ";
            Statement st;
            st =cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while(rs.next()){
                Challenges e = new Challenges (rs.getInt("id_challange"), rs.getString("duree"),rs.getString("recompense"),rs.getString("description"),rs.getInt("id_studio"));
                list.add(e);
            }
            
        }
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
        return list;
    }
//KOl STUDIO NBR DU CHALLANGE LMHABTHOM
    @Override
    public List<Challenges> afficheStudioNBChallanges() {
                  List <Challenges> list = new ArrayList<>();
        try {
            String req = "select id_studio ,count(*) as 'nb' from challanges group  by id_studio order by id_studio";  
            
            Statement st;
            st =cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while(rs.next()){
                Challenges e = new Challenges (rs.getInt("nb"),getNameUserA(rs.getInt("id_studio")));
                list.add(e);
            }
            
        }
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
        return list;
    }
//AGHLA CHALLENGE MAWJOUD
    @Override
    public List<HighChallengePublier> HightRecompenseChallanges() {
          List <HighChallengePublier> list = new ArrayList<>();
           
        try {
            String req = "SELECT MAX( CAST(TRIM(TRAILING '$' FROM c.recompense) AS INT)) as 'max',u.login FROM challanges c join user u ON c.id_studio=u.id_user";
            
            Statement st;
            st =cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while(rs.next()){
               // System.out.print("Dkhalet llwhile");
               HighChallengePublier e = new HighChallengePublier (rs.getString("login"),rs.getInt("max"));
                list.add(e);
               // System.out.print("\n7atit lmax fi e\n");
             
            }
            
        }
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
      return list;
    }

    @Override
    public void ParticiperChallenge(int idchallenge, int idArtist) {
                     String req = "INSERT INTO participer_challenges(  `id_challange`, `id_user`) VALUES ("+idchallenge+", "+idArtist+")";
        Statement st;
        
        if (SiARTISTE(idArtist)){
        try {
            st =cnx.createStatement();
            st.executeUpdate(req);
        }catch (SQLException ex){
            System.err.println(ex.getMessage());
        }}
        else 
            System.out.println("TU n'est PAS UN ARTISTE Désole");
    }

    @Override
    public List<ParticperChallenge> afficheUserParticiperChallanges(int Idchallenge) {
             List <ParticperChallenge> list = new ArrayList<>();
           //id_studio="+idstudio+"
        try {
            String req = "SELECT u.login,c.recompense from challanges c " +
                    "join participer_challenges pc on pc.id_challange=c.id_challange "+
                    "join user u on u.id_user=pc.id_user "+
                    " where c.id_challange="+Idchallenge+
                    " AND u.role like 'ARTIST'";
            //tester SI c'est Artiste pour peut Participer

            Statement st;
            st =cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while(rs.next()){
               // System.out.print("Dkhalet llwhile");
               ParticperChallenge e = new ParticperChallenge (rs.getString("login"),rs.getString("recompense"));
                list.add(e);
               // System.out.print("\n7atit lmax fi e\n");
             
            }
            
        }
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
      return list;
    }

    @Override
    public Boolean SiARTISTE(int idUser) {
             Boolean x=false;
           
        try {
            String req = "SELECT " +
"   CASE WHEN EXISTS " +
"    (  SELECT * FROM user u WHERE u.id_user= "+idUser+" AND u.role like 'ARTIST') THEN 'TRUE' " +
"    ELSE 'FALSE'" +
" END";
            //tester SI c'est Artiste pour peut Participer

            Statement st;
            st =cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while(rs.next()){
              
            x= rs.getBoolean(1);
             
            }
            
        }
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
      return x; 
    }

    @Override
    public String getNameUserA(int id) {
          String nomUser="Not FOUND";
           //id_studio="+idstudio+"
        try {
            String req = "SELECT login FROM `user` WHERE id_user="+id+"";
            //tester SI c'est Artiste pour peut Participer

            Statement st;
            st =cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while(rs.next()){
               // System.out.print("Dkhalet llwhile");
               nomUser  = rs.getString("login");
              
               // System.out.print("\n7atit lmax fi e\n");
             
            }
            
        }
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
      return nomUser;
    }

 
 

 
    
}
