/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.worshop.utils;

import edu.worshop.entites.Challenges;
import edu.worshop.entites.Formation;
import edu.worshop.entites.Studio;
import edu.worshop.services.ChallengeCrud;
import edu.worshop.services.FormationCrud;

/**
 *
 * @author msi
 */
public class GestionChallenges {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyConnexion c = MyConnexion.getIstance();
        Studio S=new Studio(1, "UBISOFT manager", "joseph kerssbi", "joseph123@gmail.com", "55619255", "Studio Manager");
          Studio S2=new Studio(2, "UBISOFT manager", "joseph kerssbi", "joseph123@gmail.com", "55619255", "We are an independent studio from Europe. Our stud..");
       // Challenges g1=new Challenges( "1 mois", "500$", "create modelling 3D Using Blender and 3DMAX only","mendoza.jpg");
        Challenges g2=new Challenges( "4 mois", "1860$", "Designing the Structures and Tools of The Forgotten Realms","Ajouter img url");
       // Challenges g5=new Challenges(20, "4 mois", "1860$", 2, "Designing the Structures and Tools of The Forgotten Realms");
        //Challenges g6=new Challenges(0, duree, recompense, 0, description)
         Challenges g4=new Challenges( "7 semains", "1000$", "Environment Design Designing the Locations of The Forgotten Realms ...","Ajouter img url");
          Challenges g3=new Challenges( "6 semaine", "2000$", "Designing the Structures and Tools of The Forgotten Realms","Ajouter img url");
        ChallengeCrud Cc= new ChallengeCrud();
      // Cc.ajouterChallenges(g2, 2);
      // Cc.ajouterChallenges(g2, S);
     // Cc.modifierChallenges(g3, S);
    // Cc.ajouterChallenges(g4, S2);
   // Cc.suprimerChallenges(3, 1);
  // Cc.ParticiperChallenge(20, 1);
      //  System.out.println(Cc.afficheUserParticiperChallanges(5));
   //   System.out.println(Cc.afficheStudioNBChallanges());
      
//------------Test pour Dali -----------
        Formation f=new Formation("Adobe", "1 mois", "Photoshop Course",156);
        Formation f2=new Formation( "Adobe","4 mois", "Adobe  illustrator",65,6);
         Formation f4=new Formation( "Adobe","7 semains", "3D Modeling",35,6);
         Formation f5=new Formation( 1,"Adobe","7 semains", "3D Modeling",35,6);
          Formation f3=new Formation( "Adobe","6 semaine", "Formation en Lightroom ",95,6);
        FormationCrud Fc= new FormationCrud();     
        
       // System.out.println(Fc.afficheFormation());  
       System.out.println(Fc.afficheStudioNBFormations());
        
    }
    
}
