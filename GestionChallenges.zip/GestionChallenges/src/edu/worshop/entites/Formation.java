/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.worshop.entites;

/**
 *
 * @author msi
 */
public class Formation {
    private int idformation;
    private String nom;
   private String duree;
    private String description;
    private int studio_id;
    public int prix;
    private int nbrFormationpublier;
    private String nom_persone_publier;

    public Formation(int nbrFormationpublier, String nom_persone_publier) {
        this.nbrFormationpublier = nbrFormationpublier;
        this.nom_persone_publier = nom_persone_publier;
    }

    public Formation(String nom,String duree, String description, int prix) {
        this.nom = nom;
        this.duree = duree;
        this.description = description;
        this.prix = prix;
       
    }

    public Formation(int idformation, String nom,String duree, String description, int prix ,int studio_id) {
        this.idformation = idformation;
        this.nom = nom;
        this.duree = duree;
        this.description = description;
        this.studio_id = studio_id;
        this.prix = prix;
       

    }

    public Formation(String nom, String duree, String description, int studio_id, int prix) {
        this.nom = nom;
        this.duree = duree;
        this.description = description;
        this.studio_id = studio_id;
        this.prix = prix;
       

    }

   
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }
    

 



    public int getIdformation() {
        return idformation;
    }

    public String getDuree() {
        return duree;
    }

    public int getStudio_id() {
        return studio_id;
    }

    public int getPrix() {
        return prix;
    }

    public void setStudio_id(int studio_id) {
        this.studio_id = studio_id;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    
    public String getDescription() {
        return description;
    }

    public void setIdformation(int idformation) {
        this.idformation = idformation;
    }

    public void setDuree(String duree) {
        this.duree = duree;
    }


    public void setDescription(String description) {
        this.description = description;
    }

    public int getNbrFormationpublier() {
        return nbrFormationpublier;
    }

    public String getNom_persone_publier() {
        return nom_persone_publier;
    }

    public void setNbrFormationpublier(int nbrFormationpublier) {
        this.nbrFormationpublier = nbrFormationpublier;
    }

    public void setNom_persone_publier(String nom_persone_publier) {
        this.nom_persone_publier = nom_persone_publier;
    }

    @Override
    public String toString() {
        return "Formation{" + "idformation=" + idformation + ", nom=" + nom + ", duree=" + duree + ", description=" + description + ", studio_id=" + studio_id + ", prix=" + prix + ", nbrFormationpublier=" + nbrFormationpublier + ", nom_persone_publier=" + nom_persone_publier + '}'+'\n';
    }




    
    
}
