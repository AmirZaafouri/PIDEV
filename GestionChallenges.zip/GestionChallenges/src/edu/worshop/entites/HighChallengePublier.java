/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.worshop.entites;

/**
 *
 * @author msi
 */
public class HighChallengePublier {
    String nomManger;
    int PrixChallenge;

    @Override
    public String toString() {
        return "HighChallengePublier{" + "nomManger=" + nomManger + ", PrixChallenge=" + PrixChallenge + '}';
    }

    public HighChallengePublier(String nomManger, int PrixChallenge) {
        this.nomManger = nomManger;
        this.PrixChallenge = PrixChallenge;
    }

    public String getNomManger() {
        return nomManger;
    }

    public int getPrixChallenge() {
        return PrixChallenge;
    }

    public void setNomManger(String nomManger) {
        this.nomManger = nomManger;
    }

    public void setPrixChallenge(int PrixChallenge) {
        this.PrixChallenge = PrixChallenge;
    }
}
