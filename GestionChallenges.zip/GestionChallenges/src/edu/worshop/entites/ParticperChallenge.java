/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.worshop.entites;

/**
 *
 * @author msi
 */
public class ParticperChallenge {
    private int Id_Participer_Challenges; 
    private int id_challange;
    private int id_user;
    private String nom_participant;
    private String RecompenseChallenge;
    public ParticperChallenge(int id_challange, int id_user) {
        this.id_challange = id_challange;
        this.id_user = id_user;
    }

    public ParticperChallenge(String nom_participant, String RecompenseChallenge) {
        this.nom_participant = nom_participant;
        this.RecompenseChallenge = RecompenseChallenge;
    }
    
 

    public ParticperChallenge(int Id_Participer_Challenges, int id_challange, int id_user) {
        this.Id_Participer_Challenges = Id_Participer_Challenges;
        this.id_challange = id_challange;
        this.id_user = id_user;
    }

  

    public int getId_Participer_Challenges() {
        return Id_Participer_Challenges;
    }

    public int getId_challange() {
        return id_challange;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_Participer_Challenges(int Id_Participer_Challenges) {
        this.Id_Participer_Challenges = Id_Participer_Challenges;
    }

    public void setId_challange(int id_challange) {
        this.id_challange = id_challange;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public void setNom_participant(String nom_participant) {
        this.nom_participant = nom_participant;
    }

    public void setRecompenseChallenge(String RecompenseChallenge) {
        this.RecompenseChallenge = RecompenseChallenge;
    }

    public String getNom_participant() {
        return nom_participant;
    }

    public String getRecompenseChallenge() {
        return RecompenseChallenge;
    }

    @Override
    public String toString() {
        return "ParticperChallenge{" + "Id_Participer_Challenges=" + Id_Participer_Challenges + ", id_challange=" + id_challange + ", id_user=" + id_user + ", nom_participant=" + nom_participant + ", RecompenseChallenge=" + RecompenseChallenge + '}';
    }
  
}
