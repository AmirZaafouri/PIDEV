/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.worshop.entites;

/**
 *
 * @author msi
 */
public class Challenges {
    private int idchallange;
    private String duree;
    private String recompense;
    private int studio_id;
    private String description;
    private  int NbrChallangePublier;
    private String img;
    //Atrubit lassemi Luser khater sta79itha fi Affiche USER + NBR publication 
    private String nom_qui_a_publier;
    public Challenges(String duree, String recompense, int studio_id, String description, int NbrChallangePublier, String img) {
        this.duree = duree;
        this.recompense = recompense;
        this.studio_id = studio_id;
        this.description = description;
        this.NbrChallangePublier = NbrChallangePublier;
        this.img = img;
    }
               //duree, recomponce, descrption,imgUrl
    public Challenges(int idchallange, String duree, String recompense, String description, int studio_id) {
        this.idchallange = idchallange;
        this.duree = duree;
        this.recompense = recompense;
        this.studio_id = studio_id;
        this.description = description;
    }

    public Challenges(int idchallange, String duree, String recompense, int studio_id, String description, int NbrChallangePublier, String img) {
        this.idchallange = idchallange;
        this.duree = duree;
        this.recompense = recompense;
        this.studio_id = studio_id;
        this.description = description;
        this.NbrChallangePublier = NbrChallangePublier;
        this.img = img;
    }

    public Challenges(String duree, String recompense, String description) {
        this.duree = duree;
        this.recompense = recompense;
        this.description = description;
    }
 public Challenges(String duree, String recompense, String description, String img) {
        this.duree = duree;
        this.recompense = recompense;
        this.description = description;
        this.img = img;
    }
    public Challenges(int idchallange, String duree, String recompense, int studio_id, String description, String img) {
        this.idchallange = idchallange;
        this.duree = duree;
        this.recompense = recompense;
        this.studio_id = studio_id;
        this.description = description;
        this.img = img;
    }

    
   
    
    

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
 
    public void setNbrChallangePublier(int NbrChallangePublier) {
        this.NbrChallangePublier = NbrChallangePublier;
    }
 

    public int getNbrChallangePublier() {
        return NbrChallangePublier;
    }

    public Challenges(int NbrChallangePublier, String nom_qui_a_publier) {
        this.NbrChallangePublier = NbrChallangePublier;
        this.nom_qui_a_publier = nom_qui_a_publier;
    }

   

    public void setStudio_id(int studio_id) {
        this.studio_id = studio_id;
    }

    public int getStudio_id() {
        return studio_id;
    }



  



    public int getIdchallange() {
        return idchallange;
    }

    public String getDuree() {
        return duree;
    }

    public String getRecompense() {
        return recompense;
    }

    public String getDescription() {
        return description;
    }

    public void setIdchallange(int idchallange) {
        this.idchallange = idchallange;
    }

    public void setDuree(String duree) {
        this.duree = duree;
    }

    public void setRecompense(String recompense) {
        this.recompense = recompense;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Challenges{" + "idchallange=" + idchallange + ", duree=" + duree + ", recompense=" + recompense + ", studio_id=" + studio_id + ", description=" + description + ", NbrChallangePublier=" + NbrChallangePublier + ", img=" + img + ", nom_qui_a_publier=" + nom_qui_a_publier + '}'+'\n';
    }

   

    public String getNom_qui_a_publier() {
        return nom_qui_a_publier;
    }

    public void setNom_qui_a_publier(String nom_qui_a_publier) {
        this.nom_qui_a_publier = nom_qui_a_publier;
    }


  
    
    
}
